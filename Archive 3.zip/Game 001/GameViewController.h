//
//  GameViewController.h
//  Game 001
//

//  Copyright (c) 2015 Chen Zhibo. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>
@import GameKit;

@interface GameViewController : UIViewController

@property (strong, nonatomic) GKMatch *currentMatch;



@end
